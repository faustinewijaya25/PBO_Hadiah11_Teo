/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiahteo;
import java.awt.*;
public class Hadiahteo extends Panel{
    /**
     * @param args the command line arguments
     */
    
    Hadiahteo() {
        setBackground(Color.GRAY);
    }
    public void paint(Graphics g) {  
        //rambut
        g.setColor(Color.cyan);
        g.drawOval(180, 8, 150, 200);
        g.fillOval(180, 8, 150, 200);
        
        g.setColor(Color.black);
        g.drawOval(200, 8, 100, 55);
        g.fillOval(200, 8, 100, 55);
        //kepala
        g.setColor(Color.white);
        g.drawOval(200, 10, 110, 110);
        g.fillOval(200, 10, 110, 110);    
        //mata
        g.setColor(Color.black);
        g.drawOval(230, 50, 8, 5);
        g.fillOval(230, 50, 8, 5); 
        
        g.setColor(Color.black);
        g.drawOval(270, 50, 8, 5);
        g.fillOval(270, 50, 8, 5); 
        //mulut
        g.setColor(Color.pink);
        g.drawArc(250, 80, 15, 15, 10, -200);
        //badan
        g.drawLine(100, 150, 400, 150);
        g.drawLine(255, 120, 255, 300);
        g.drawLine(255, 300, 100, 400);
        g.drawLine(255, 300, 400, 400);
        
        
        
             
       
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Testing Graphics Panel");
        Hadiahteo gp = new Hadiahteo();
        f.add(gp);
        f.setSize(600,600);
        f.setVisible(true);
    }
    
}